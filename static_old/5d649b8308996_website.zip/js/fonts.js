"use strict";

WebFont.load({
    google: {
        families: [
            'Lora:400,700,latin,cyrillic,cyrillic-ext',
            'Roboto:100,100italic,700,700italic,latin,cyrillic,cyrillic-ext',


            'Open+Sans:400,700,700italic,400italic,latin,cyrillic,cyrillic-ext',
        ]
    }
});